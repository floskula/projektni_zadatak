import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { HomeScreen } from "../screens/HomeScreen";
import { SettingsScreen } from "../screens/SettingsScreen";
import { HomeScreen1 } from "../screens/HomeScreen1";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Ionicons from "@expo/vector-icons/Ionicons";

const Stack = createStackNavigator();

export function MyStack() {
  return (
    <Stack.Navigator>
    <Stack.Screen
        name="Home"
        component={HomeScreen1}
        options={{ title: "home" }}
      />
      <Stack.Screen
        name="Person"
        component={HomeScreen}
        options={{ title: "Person" }}
      />
      <Stack.Screen
        name="Send"
        component={SettingsScreen}
        options={{ title: "Send one" }}
      />
    </Stack.Navigator>
  );
}

const Tab = createBottomTabNavigator();

export function TabNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === "home") {
              iconName = focused ? "home" : "home-outline";
            }else if  (route.name === "list") {
              iconName = focused ? "list" : "list-outline";
            }else if (route.name === "send") {
              iconName = focused ? "send" : "send-outline";
            }

            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#ae60bc',
          tabBarInactiveTintColor: "gray",
        })}
      >


        <Tab.Screen
          name="home"
          component={HomeScreen1}
          options={{
            headerTitle: "HOME",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: '#ae60bc',
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "HOME",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />
        <Tab.Screen
          name="list"
          component={HomeScreen}
          options={{
            headerTitle: "PERSON",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: '#ae60bc',
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "PERSON",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />
        <Tab.Screen
          name="send"
          component={SettingsScreen}
          options={{
            headerTitle: "Send one!",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: '#ae60bc',
              textAlign: 'center',
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "SEND ONE",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}