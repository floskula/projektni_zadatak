
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  TextInput,
  FlatList,
  Pressable,
  ScrollView,
} from 'react-native';

export function SettingsScreen({ route, navigation }) {
  const [name, setName] = useState('');
  const [surname, setSurname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const sendRequest = async () => {
    try {
      await fetch('https://webhook.site/8fca78f7-31e9-4084-9e30-492c12ae8ca7', {
        method: 'post',
        mode: 'no-core',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: name,
          surname: surname,
          email: email,
          password: password,
        }),
      });
      setName('');
      setSurname('');
      setEmail('');
      setPassword('');
    } catch (error) {}
  };

  function handleSettingsPress() {
    navigation.navigate('Settings');
  }

  return (
    <ScrollView style={styles.screen}>
      <View style={styles.inputWrapper}>
        <Text style={styles.inputText}>First name:</Text>
        <TextInput style={styles.input} onChangeText={setName} value={name} />
      </View>

      <View style={styles.inputWrapper}>
        <Text style={styles.inputText}>Last name:</Text>
        <TextInput
          style={styles.input}
          onChangeText={setSurname}
          value={surname}
        />
      </View>

      <View style={styles.inputWrapper}>
        <Text style={styles.inputText}>E-mail: </Text>
        <TextInput style={styles.input} onChangeText={setEmail} value={email} />
      </View>

      <View style={styles.inputWrapper}>
        <Text style={styles.inputText}>Pass: </Text>
        <TextInput
          style={styles.input}
          onChangeText={setPassword}
          value={password}
          secureTextEntry={true}
        />
      </View>

     <Pressable style={styles.button} onPress={sendRequest}>
      <Text style={styles.text}>Send</Text>
    </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: 'center',
    //justifyContent: "center",
    backgroundColor: '#cb99d4',
  },
  inputWrapper: {
    alignItems: 'center',
  },
  input: {
    height: 25,
    width: 200,
    margin: 12,
    padding: 5,
    backgroundColor: "white"
  },
    button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 4,
    elevation: 3,
    backgroundColor: '#ae60bc',
    margin: 20,
    marginTop: 40,
    },
  inputText: {
    fontSize: 16,
    color: "#fff",
    fontWeight: "bold",
    marginTop: 20,
  },
  text: {
    fontSize: 16,
    color: "#fff",
    fontWeight: "bold",
  }
});