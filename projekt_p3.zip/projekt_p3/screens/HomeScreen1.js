import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { Searchbar } from 'react-native-paper';


export function HomeScreen1({route, navigation}){
 function handleHomePress() {
    navigation.navigate('Home');
}

    return (
    <ScrollView style={styles.container}>
      <View>
        <Text style={styles.Text}>GOODBYE FFOS</Text>
        <Text style={styles.Text1}>App</Text>
      </View>
      </ScrollView>

);
}

const styles = StyleSheet.create({
  container: {
    flex: 2,
    flexDirection: "column",
    backgroundColor: '#cb99d4',
    paddingTop: 5
},
Text: {
  color: "#FBF5F4", 
  fontSize:50, 
  lineHeight: 51, 
  fontWeight: 'bold', 
  letterSpacing: 0.9,
  textAlign: 'center',
  paddingTop: 280,
},Text1: {
  color: "#FBF5F4", 
  fontSize:20, 
  lineHeight: 51, 
  fontWeight: 'bold', 
  letterSpacing: 0.9,
  textAlign: 'center',
},

  },

);
